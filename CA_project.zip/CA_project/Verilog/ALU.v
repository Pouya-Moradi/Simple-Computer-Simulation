`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    10:52:10 12/29/2022 
// Design Name: 
// Module Name:    ALU 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module ALU(input [15:0] A,
           input [15:0]B,
			  input [2:0] ALUsel,
			  output reg [15:0] resault
    );
 
 always @(*)
 begin
 resault=0;
  case(ALUsel)
  3'b000:
  begin
   resault = (A&B);
  end
  3'b001:
  begin
   resault = (A|B);
  end
  4'b010:
  begin
   resault = A+B;
  end
  4'b110:
  begin
   resault = A-B;
  end
  endcase
  end
  
endmodule


