`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    01:44:57 01/16/2023 
// Design Name: 
// Module Name:    Data_memory 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Data_memory(
   input[15:0] address, 
	input[15:0] write_data, 
	input MemWrite, 
	input MemRead,
	input clk, 
	output reg[16:0] read_data
    );
   reg [15:0] ram [65535:0];
	always @*
   begin
	if(MemWrite==1)
      ram[address]=write_data;
   if(MemRead==1)
      begin 
      read_data=ram[address];
      end
   end


endmodule
