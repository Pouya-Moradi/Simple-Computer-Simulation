`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   11:05:41 12/29/2022
// Design Name:   ALU
// Module Name:   C:/verilog/ALU/ALU_test.v
// Project Name:  ALU
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: ALU
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module ALU_test;

	// Inputs
	reg [15:0] A;
	reg [15:0] B;
	reg [2:0] ALUsel;

	// Outputs
	wire [15:0] resault;

	// Instantiate the Unit Under Test (UUT)
	ALU uut (
		.A(A), 
		.B(B), 
		.ALUsel(ALUsel), 
		.resault(resault)
	);

	initial begin

		A = 10;
		B = 3;
		
		ALUsel = 0;
		#100;
		ALUsel = 1;
		#100;
		ALUsel = 2;
		#100;
		ALUsel = 6;
		#100;
		$finish;

	end
      
endmodule

