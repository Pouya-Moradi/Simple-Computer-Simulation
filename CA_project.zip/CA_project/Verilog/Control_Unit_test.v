`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   12:59:35 12/28/2022
// Design Name:   Control_Unit
// Module Name:   C:/verilog/Control_Unit/Control_Unit_test.v
// Project Name:  Control_Unit
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Control_Unit
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Control_Unit_test;

	// Inputs
	reg [3:0] OP;
	reg [2:0] func;

	// Outputs
	wire RegDes;
	wire ALUSrc;
	wire MemtoReg;
	wire RegWrite;
	wire MemRead;
	wire MemWrite;
	wire [2:0] ALUsel;

	// Instantiate the Unit Under Test (UUT)
	Control_Unit uut (
		.OP(OP), 
		.func(func), 
		.RegDes(RegDes), 
		.ALUSrc(ALUSrc), 
		.MemtoReg(MemtoReg), 
		.RegWrite(RegWrite), 
		.MemRead(MemRead), 
		.MemWrite(MemWrite),
		.ALUsel(ALUsel)
	);

	initial begin
		// Initialize Inputs
		OP = 0;
		func = 4;
		#100;
		OP = 0;
		func = 5;
		#100;
		OP = 0;
		func = 0;
		#100;
		OP = 0;
		func = 2;
		#100;
		OP = 1;
		#100;
		OP = 2;
		#100;

		$finish;

	end
      
endmodule

