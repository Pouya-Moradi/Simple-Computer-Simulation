`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    05:33:59 01/16/2023 
// Design Name: 
// Module Name:    Main 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Main(input clk);
   reg [15:0] pc;
   wire RegWrite;
	wire MemWrite;
	wire MemRead;
	wire MemtoReg;
	wire ALUSrc;
	wire branch;
	wire RegDes;
	wire [2:0] ALUsel;
	wire [18:0] ins_data;
	wire [15:0] reg_d1;
	wire [15:0] reg_d2;
	wire [31:0] out;
	wire [31:0] readdata;
	
	
	Ins_mem ins_mem(pc, ins_data);
	
	always @(posedge clk)
	begin
		if ( branch )
			pc <= { ins_data[14], ins_data[14:0] };
		else
			pc <= pc + 2;
	end
	
   reg [16:0] out_write_data;	
	always @(*)
	begin
		if (MemtoReg)
			out_write_data <= readdata;
		else
			out_write_data <= out;
	end
	
	Control_Unit control_unit(ins_data[18:15]/*OP*/ ,ins_data[2:0]/*func*/, RegDes, ALUSrc, MemtoReg, RegWrite,  MemRead, MemWrite, branch, ALUsel);
	
	reg [3:0] out_reg_dst;	
	always @(*)
	begin
		if (RegDes)
			out_reg_dst <= ins_data [6:3];
		else
			out_reg_dst <= ins_data [10:7];
	end
	
	Register_File reg_file( clk, out_write_data, RegWrite, ins_data[14:11] ,ins_data[10:7], out_reg_dst, reg_d1, reg_d2);
	
	reg [15:0] inp_alu;
	always @(*)
	begin
		if (ALUSrc)
			inp_alu <={ {9{ins_data[6]}}, ins_data [6:0] };//sign extended
		else
			inp_alu <= reg_d2;
	end
	
	ALU alu(reg_d1, inp_alu, ALUsel, out);
	Data_memory data_memory( out, reg_d2, MemWrite, MemRead, clk, readdata);

endmodule
