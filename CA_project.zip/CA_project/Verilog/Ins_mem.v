`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    00:56:00 01/16/2023 
// Design Name: 
// Module Name:    Ins_mem 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Ins_mem(
   input[15:0] address, 
	output reg [18:0] data
    );
	 reg [15:0] ram [65535:0];
	 
	 always @ (*)
	 begin
	 data = ram[address];
	 end


endmodule
