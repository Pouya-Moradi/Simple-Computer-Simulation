`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    12:25:13 12/28/2022 
// Design Name: 
// Module Name:    Control_Unit 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Control_Unit(input [3:0] OP,
                    input [2:0] func,
						  output reg RegDes, 
						  output reg ALUSrc,
						  output reg MemtoReg, 
						  output reg RegWrite, 
						  output reg MemRead,
						  output reg MemWrite,  
						  output reg [2:0] ALUsel 
    );
		 reg Op1, Op2, Op3, Op4;
		 reg func1, func2, func3;
		 reg load;
		 reg store; 
		 reg R_type;
		 reg ALUop;
		 
	always @(*)
		begin
		 {Op4, Op3, Op2, Op1} = OP;
		 {func3, func2, func1} = func;
		 
		 R_type = ~Op1 && ~Op2 && ~Op3 && ~Op4;
		 load = Op1 && ~Op2 && ~Op3 && ~Op4;
		 store = ~Op1 && Op2 && ~Op3 && ~Op4;
       		 	 
	    RegDes = R_type;
		 ALUSrc = load || store;
		 MemtoReg = load;
		 RegWrite = load || R_type;
		 MemRead = load;
		 MemWrite = store;
		 ALUop = R_type;
		 ALUsel[0] = ALUop && func1;
       ALUsel[1] = ~ALUop || ~func3;
       ALUsel[2] = ALUop && func2;	 
		end  

endmodule
