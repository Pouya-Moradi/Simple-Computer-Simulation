`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    02:24:29 01/16/2023 
// Design Name: 
// Module Name:    Register_File 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Register_File(
   input clk, 
	input [15:0] writedata, 
	input RegWrite, 
	input [3:0] regread_1, 
	input [3:0] regread_2,
	input [3:0] regdst, 
	output [15:0] reg_d1, 
	output [15:0] reg_d2
    );
	reg[15:0] memory [0:15];
	
	always @(posedge clk)
	begin
		if(RegWrite)
		 memory[regdst] <= writedata;
	end

	assign reg_d1 = memory[regread_1];
	assign reg_d2 = memory[regread_2];

endmodule
