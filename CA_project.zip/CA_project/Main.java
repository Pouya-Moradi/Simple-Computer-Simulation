package assembler;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Register[] registerFile = new Register[16];
        registerFile[0] = new Register("zero", toBinaryConvertor(0,4), 0);
        registerFile[1] = new Register("v0", toBinaryConvertor(1,4), 0);
        registerFile[2] = new Register("a0", toBinaryConvertor(2,4), 0);
        registerFile[3] = new Register("a1", toBinaryConvertor(3,4), 0);
        for (int i = 0; i<4; i++){
            registerFile[i+4] = new Register("t"+i, toBinaryConvertor(i+4,4), 0);
            registerFile[i+8] = new Register("s"+i, toBinaryConvertor(i+8,4), 0);
        }
        registerFile[12] = new Register("gp", toBinaryConvertor(12,4), 0);
        registerFile[13] = new Register("sp", toBinaryConvertor(13,4), 0);
        registerFile[14] = new Register("fp", toBinaryConvertor(14,4), 0);
        registerFile[15] = new Register("ra", toBinaryConvertor(15,4), 0);

        System.out.println("Please enter the number of instructions you want to enter");
        int numberOfInputs = Integer.valueOf(input.nextLine());
        String[] inputInstructions = new String[numberOfInputs];

        System.out.println("Enter your Instructions");
        String[] machineCodes = new String[numberOfInputs];
        String opCode = "";
        String funcCode = "";
        for (int i = 0; i<numberOfInputs;i++){
            inputInstructions[i] = new String();
            inputInstructions[i] = input.nextLine();

            inputInstructions[i] = inputInstructions[i].toLowerCase();

            String instrOp = inputInstructions[i].substring(0,inputInstructions[i].indexOf(' '));

            if (instrOp.equals("and")) {
                opCode = "0000";
                funcCode = "100";
                String reg1 = inputInstructions[i].substring(5,7);
                String reg2 = inputInstructions[i].substring(10,12);
                String reg3 = inputInstructions[i].substring(15);
                String reg1BinaryCode = "";
                String reg2BinaryCode = "";
                String reg3BinaryCode = "";
                for (int j = 0; j < 16; j++) {
                    if (registerFile[j].getRegisterName().equals(reg1)) {
                        reg1BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg2)) {
                        reg2BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg3)) {
                        reg3BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                }
                String andMachineCode = opCode + reg1BinaryCode + reg2BinaryCode + reg3BinaryCode + funcCode;
                machineCodes[i] = new String();
                machineCodes[i] = andMachineCode;
            }

            if (instrOp.equals("or")) {
                opCode = "0000";
                funcCode = "101";
                String reg1 = inputInstructions[i].substring(4,6);
                String reg2 = inputInstructions[i].substring(9,11);
                String reg3 = inputInstructions[i].substring(14);
                String reg1BinaryCode = "";
                String reg2BinaryCode = "";
                String reg3BinaryCode = "";
                for (int j = 0; j < 16; j++) {
                    if (registerFile[j].getRegisterName().equals(reg1)) {
                        reg1BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg2)) {
                        reg2BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg3)) {
                        reg3BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                }
                String orMachineCode = opCode + reg1BinaryCode + reg2BinaryCode + reg3BinaryCode + funcCode;
                machineCodes[i] = orMachineCode;
            }

            if (instrOp.equals("add")) {
                opCode = "0000";
                funcCode = "000";
                String reg1 = inputInstructions[i].substring(5,7);
                String reg2 = inputInstructions[i].substring(10,12);
                String reg3 = inputInstructions[i].substring(15);
                String reg1BinaryCode = "";
                String reg2BinaryCode = "";
                String reg3BinaryCode = "";
                for (int j = 0; j < 16; j++) {
                    if (registerFile[j].getRegisterName().equals(reg1)) {
                        reg1BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg2)) {
                        reg2BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg3)) {
                        reg3BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                }
                String addMachineCode = opCode + reg1BinaryCode + reg2BinaryCode + reg3BinaryCode + funcCode;
                machineCodes[i] = addMachineCode;
            }

            if (instrOp.equals("sub")) {
                opCode = "0000";
                funcCode = "010";
                String reg1 = inputInstructions[i].substring(5,7);
                String reg2 = inputInstructions[i].substring(10,12);
                String reg3 = inputInstructions[i].substring(15);
                String reg1BinaryCode = "";
                String reg2BinaryCode = "";
                String reg3BinaryCode = "";
                for (int j = 0; j < 16; j++) {
                    if (registerFile[j].getRegisterName().equals(reg1)) {
                        reg1BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg2)) {
                        reg2BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg3)) {
                        reg3BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                }
                String subMachineCode = opCode + reg1BinaryCode + reg2BinaryCode + reg3BinaryCode + funcCode;
                machineCodes[i] = subMachineCode;
            }

            if (instrOp.equals("lw")) {
                opCode = "0001";
                String reg1 = inputInstructions[i].substring(4,6);
                String reg2 = inputInstructions[i].substring(inputInstructions[i].indexOf('(')+2,inputInstructions[i].indexOf(')'));
                int imm = Integer.valueOf(inputInstructions[i].substring(inputInstructions[i].indexOf(',')+2, inputInstructions[i].indexOf('(')));
                String reg1BinaryCode = "";
                String reg2BinaryCode = "";
                String immCode = toBinaryConvertor(imm,7);
                for (int j = 0; j < 16; j++) {
                    if (registerFile[j].getRegisterName().equals(reg1)) {
                        reg1BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg2)) {
                        reg2BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                }
                String lwMachineCode = opCode + reg1BinaryCode + reg2BinaryCode + immCode;
                machineCodes[i] = lwMachineCode;
            }

            if (instrOp.equals("sw")) {
                opCode = "0010";
                String reg1 = inputInstructions[i].substring(4,6);
                String reg2 = inputInstructions[i].substring(inputInstructions[i].indexOf('(')+2,inputInstructions[i].indexOf(')'));
                int imm = Integer.valueOf(inputInstructions[i].substring(inputInstructions[i].indexOf(',')+2, inputInstructions[i].indexOf('(')));
                String reg1BinaryCode = "";
                String reg2BinaryCode = "";
                String immCode = toBinaryConvertor(imm,7);
                for (int j = 0; j < 16; j++) {
                    if (registerFile[j].getRegisterName().equals(reg1)) {
                        reg1BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                    if (registerFile[j].getRegisterName().equals(reg2)) {
                        reg2BinaryCode = registerFile[j].getRegisterBinaryCode();
                    }
                }
                String swMachineCode = opCode + reg1BinaryCode + reg2BinaryCode + immCode;
                machineCodes[i] = swMachineCode;
            }

            if (instrOp.equals("jump")) {
                opCode = "0011";
                int imm = Integer.valueOf(inputInstructions[i].substring(inputInstructions[i].indexOf(' ')+1));
                String reg1BinaryCode = "";
                String reg2BinaryCode = "";
                String immCode = toBinaryConvertor(imm,15);
                String jumpMachineCode = opCode + reg1BinaryCode + reg2BinaryCode + immCode;
                machineCodes[i] = jumpMachineCode;
            }



        }

            for (int i = 0; i < numberOfInputs; i++) {
                System.out.println(machineCodes[i]);
            }

    }

    public static String toBinaryConvertor(int convertingValue, int length){
        int[] binary = new int[length];
        int index = 0;
        while (convertingValue > 0){
            binary[index++] = convertingValue%2;
            convertingValue = convertingValue/2;
        }
        String binaryOutput = "";
        for (int i = index-1; i>=0; i--){
            binaryOutput += String.valueOf(binary[i]);
        }

        if(binaryOutput.length()<length){
            int difference = length-binaryOutput.length();
            String differentialZeros = "";
            for (int j = 0; j<difference; j++){
                differentialZeros += "0";
            }
            binaryOutput = differentialZeros + binaryOutput;
        }

        return binaryOutput;
    }
}

public class Register {

    private String registerName;
    private String registerBinaryCode;
    private int registerValue;

    public Register(String registerName, String registerBinaryCode, int registerValue){
        this.registerName = registerName;
        this.registerBinaryCode = registerBinaryCode;
        this.registerValue = registerValue;
    }

    public String getRegisterName() {
        return registerName;
    }

    public void setRegisterName(String registerName) {
        this.registerName = registerName;
    }

    public String getRegisterBinaryCode() {
        return registerBinaryCode;
    }

    public void setRegisterBinaryCode(String registerBinaryCode) {
        this.registerBinaryCode = registerBinaryCode;
    }

    public int getRegisterValue() {
        return registerValue;
    }

    public void setRegisterValue(int registerValue) {
        this.registerValue = registerValue;
    }
}
